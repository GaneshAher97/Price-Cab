import { View,Text
 } from "react-native";

 const Selfie = () =>{
    return(
        <View> 
            <Text>Hello </Text>
        </View>
    )

 }
 export default Selfie;